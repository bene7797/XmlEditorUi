Der UploadClient (Version 1.5)


Dieser UploadClient erm�glicht die �bertragung des Openq-Katalogs (http- und https-Protokoll) zur Kursnet-Anwendung.
Der UploadClient kommuniziert hierbei mit dem WebService der Anwendung "KURSNET - Bildung einfach anbieten".


Inhaltsverzeichnis 
1. Inhalt des Zip-Archivs:
2. Die Parameter von uploadclient.conf
3. Starten des Clients


1. Inhalt des Zip-Archivs:

Libraries:
Die libraries im Unterverzeichnis lib sind f�r die Nutzung des Uploadclients notwendig.

lib/de und lib/openq: 
Beinhaltet den UploadClient und die Stubs.

etc/uploadclient.conf: 
Ist die Konfigurationsdatei f�r den UploadClient.

etc/uploadclient.keystore: 
Dieser Keystore beinhaltet das Zertifikat von TC TrustCenter (http://www.trustcenter.de), bei dem das SSL-Zertificat der Kursnet-Anwendung Zertifiziert wurde.

bin/uploadclient_start.sh und bin/uploadclient_start.bat: 
Sind Beispiele f�r eine m�gliche Benutzung des UploadClients.

openq.wsdl:
Diese Web Service Description Language Datei (WSDL) definiert eine plattform-, programmiersprachen-
und protokollunabh�ngige XML-Spezifikation zur Beschreibung des Netzwerkdienstes (hier Web Services f�r den OpenQ-Katalog-Austausch).


2. Die Parameter von uploadclient.conf

<benutzer> und <passwort> 
Sind die Anmeldeinformationen des Ansprechpartners bei "KURSNET - Bildung einfach anbieten".

Folgende Parameter sind wichtig, wenn Ihr Computer sich in einem Netzwerk befindet und der Zugriff auf das www �ber einen Proxy-Server stattfindet.
In diesem Fall k�nnen die Proxy-informationen f�r http und https hier konfiguriert werden.
<http.proxyHost>, <http.proxyPort>
<https.proxyHost>, <https.proxyPort>

<katalog>
Gibt die Position des zu �bertragenden Katalogs an. Hierbei muss der gesamte Pfad mit dem Dateinamen angegeben werden:
Unter Unix:
katalog=/home/user/hban/my_katalog.xml
Unter Windows:
katalog=c:\\kataloge\\hban\\my_katalog.xml

<action>
Diese Option ist f�r den Upload vorgesehen.
M�gliche Werte sind 1 und 2.
1 = Ihr Katalog wird auf Validit�t, Plausibilit�t und vollst�ndigkeit �berpr�ft, um die m�glichen Fehler bei weiterer Verarbeitung in Kursnet auszuschlie�en.
Die R�ckmeldung der �berpr�fung des Katalogs wird an den Client zur�ckgeliefert.
2 = Hierbei wird der Katalog gleichen Pr�fungskriterien wie bei 1 unterzogen. War die �berpr�fung erfolgreich verlaufen, so wird der Katalog f�r die weitere Verarbeitung bei Kursnet abgespeichert. War die �berpr�fung hingegen nicht positiv, erfolgt eine R�ckmeldung zum UploadClient (wie bei 1).
 
<aufgabe>
Mit dieser Option kann festgelegt werden, ob der Katalog an die Kursnet-Anwendung �bermittelt oder von der Kursnet-Anwendung abgeholt werden soll. Mit dem Wert 'test' wird lediglich eine Verbindung zum Kursnet-Webservice aufgebaut.
M�gliche Werte sind: "test", "upload" oder "download".
Bei "upload" wird der Katalog unter Verwendung der Optionen <katalog> und <action> zur Kursnet-Anwendung �bertragen.
Bei "download"  wird der katalog in der Kursnet-Anwendung erstellt und an den UploadClient �bertragen. Hierbei muss die Option <speichernunter_zip> definiert sein.
Bei "test" wird versucht den Webservice f�r Testzwecke zu kontaktieren.

<speichernunter_zip>
Hier kann definiert werden, in welchem Verzeichnis und unter welchem Dateinamen der heruntergeladene Katalog abgespeichert werden soll. Die �bertragung des Katalogs findet hierbei im Zip-Format statt.
Beachten Sie, dass das angegebene Verzeichnis existieren muss.
In dem Zip-Archiv wird der Dateiname nach folgendem Muster erstellt:
openq_{ban_id}_{Monat}_{Tag}-{Stunden}_{Minuten}_{Sekunden}.xml


3. Starten des Clients

a) Das Archiv auspacken (z.B. c:\...\uploadclient
b) uploadclient_start.bat oder uploadclient_start.sh anpassen:
in uploadclient_start.bat  muss die Umgebungsvariable 'DIR' und 
in uploadclient_start.sh  muss die Umgebungsvariable DIRUPLOAD zugewiesen werden 
set DIR=c:\...\uploadclient
DIRUPLOAD=/home1/.../uploadclient
Hierbei muss immer der Pfad angegeben werden, in den das ZIP-Archiv entpackt wurde.

c) Konfigurieren der Anwendung
Siehe dazu 2.